﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float move_speed;
    private float currentMoveSpeed;

    private Animator anim;
    private Rigidbody2D myRigidBody;

    public Vector2 lastMove;
    private Vector2 moveInput;
    private bool playerMoving;

    private static bool playerExists;

    public bool canMove;

    // Use this for initialization
    void Start()
    {
        anim = GetComponent<Animator>();
        myRigidBody = GetComponent<Rigidbody2D>();

        canMove = true;
        lastMove = new Vector2(0f, -1f);
    }

    // Update is called once per frame
    void Update()
    {
        playerMoving = false;

        if (!canMove)
        {
            myRigidBody.velocity = Vector2.zero;
            return;
        }

        moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;
        if (moveInput != Vector2.zero)
        {
            myRigidBody.velocity = new Vector2(moveInput.x * move_speed, moveInput.y * move_speed);
            playerMoving = true;
            lastMove = moveInput;
        }
        else
        {
            myRigidBody.velocity = Vector2.zero;
        }

        anim.SetFloat("MoveX", Input.GetAxisRaw("Horizontal"));
        anim.SetFloat("MoveY", Input.GetAxisRaw("Vertical"));
        anim.SetBool("PlayerMoving", playerMoving);
        anim.SetFloat("LastMoveX", lastMove.x);
        anim.SetFloat("LastMoveY", lastMove.y);
    }
}
